OVERLEAF INSTRUCTIONS

1. Open Overleaf and choose New Project > Upload Project.
2. Upload Iowa_House_Price_Overleaf.zip, or upload this entire folder.
3. Open main.tex.
4. Verify the group-member names, course, and submission date in the first three editable lines.
5. Set the compiler to pdfLaTeX if Overleaf does not select it automatically.
6. Click Recompile.

The project contains:
- main.tex: complete report source
- zillow_optional_section.tex: optional current-listing application
- final_ols_parameters.tex: generated parameter appendix
- figures/: four report figures
- generate_report_assets.py: optional reproducibility script

The report is based on notebooks/02_modeling_new.ipynb and random seed 20260928.
The optional section uses the same Ames property for its 2008 held-out sale and
2026 Zillow listing comparison. Public listing values were captured on October 4,
2026.
