OVERLEAF INSTRUCTIONS

1. Open Overleaf and choose New Project > Upload Project.
2. Upload iowa_house_price_overleaf.zip, or upload this entire folder.
3. Open main.tex.
4. Replace Student Name 1 and Student Name 2 in the first three editable lines.
5. Set the compiler to pdfLaTeX if Overleaf does not select it automatically.
6. Click Recompile.

The project contains:
- main.tex: complete report source
- final_ols_parameters.tex: generated parameter appendix
- figures/: four report figures
- generate_report_assets.py: optional reproducibility script

The report is based on notebooks/02_modeling (3).ipynb and random seed 20260928.
