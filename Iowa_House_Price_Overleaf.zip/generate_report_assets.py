"""Generate figures and the final constrained-OLS parameter table for the report."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer, TransformedTargetRegressor
from sklearn.linear_model import Lasso, LinearRegression, Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, StandardScaler


ROOT = Path(__file__).resolve().parents[3]
DATA_PATH = ROOT / "data" / "IA_House_Price_Original_Data.xlsx"
OUTPUT_DIR = Path(__file__).resolve().parent
FIGURE_DIR = OUTPUT_DIR / "figures"
TARGET = "SalePrice"
RANDOM_SEED = 20260928

numeric_features = [
    "LotArea", "OverallQual", "OverallCond", "YearBuilt", "YearRemodAdd",
    "BsmtFinSF", "BsmtUnfSF", "TotalBsmtSF", "1stFlrSF", "2ndFlrSF",
    "GrLivArea", "FullBath", "HalfBath", "BedroomAbvGr", "TotRmsAbvGrd",
    "Fireplaces", "GarageCars", "GarageArea", "WoodDeckSF", "OpenPorchSF",
    "EnclosedPorch",
]
neighborhoods = [
    "Blmngtn", "Blueste", "BrDale", "BrkSide", "ClearCr", "CollgCr",
    "Crawfor", "Edwards", "Gilbert", "IDOTRR", "MeadowV", "Mitchel",
    "NAmes", "NPkVill", "NWAmes", "NoRidge", "NridgHt", "OldTown",
    "SWISU", "Sawyer", "SawyerW", "Somerst", "StoneBr", "Timber", "Veenker",
]
neighborhood_columns = [f"NBHD_{name}" for name in neighborhoods]
bsmtqual_map = {"Ex": 5, "Gd": 4, "TA": 3, "Fa": 2, "Po": 1, "NA": 0}
scaled_features = numeric_features + ["BsmtQual_ordinal"]


def make_model(estimator, numeric_columns=None, dummy_columns=None):
    numeric_columns = numeric_columns or scaled_features
    dummy_columns = dummy_columns or neighborhood_columns
    preprocessing = ColumnTransformer(
        [("scaled", StandardScaler(), numeric_columns),
         ("neighborhood", "passthrough", dummy_columns)],
        verbose_feature_names_out=False,
    )
    regressor = Pipeline([("preprocess", preprocessing), ("model", estimator)])
    target_transformer = Pipeline([
        ("log", FunctionTransformer(np.log1p, inverse_func=np.expm1, validate=False)),
        ("scale", StandardScaler()),
    ])
    return TransformedTargetRegressor(
        regressor=regressor,
        transformer=target_transformer,
    )


def log_metrics(actual_price, predicted_price):
    actual_log = np.log1p(actual_price)
    predicted_log = np.log1p(np.maximum(predicted_price, 0))
    return {
        "mse": mean_squared_error(actual_log, predicted_log),
        "rmse": np.sqrt(mean_squared_error(actual_log, predicted_log)),
        "mae": mean_absolute_error(actual_log, predicted_log),
        "r2": r2_score(actual_log, predicted_log),
    }


def latex_escape(value):
    return str(value).replace("_", r"\_")


def main():
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    raw = pd.read_excel(DATA_PATH, skiprows=3)
    raw.columns = raw.columns.astype(str).str.strip()
    raw = raw.loc[:, ~raw.columns.str.startswith("Unnamed")].copy()
    raw["BsmtFinSF"] = raw["BsmtFinSF1"] + raw["BsmtFinSF2"]
    raw["BsmtQual_ordinal"] = raw["BsmtQual"].fillna("NA").map(bsmtqual_map)
    dummies = pd.get_dummies(raw["Neighborhood"], prefix="NBHD", dtype=int).reindex(
        columns=neighborhood_columns, fill_value=0
    )
    X = pd.concat([raw[numeric_features], raw[["BsmtQual_ordinal"]], dummies], axis=1)
    y = raw[TARGET].copy()

    rng = np.random.default_rng(RANDOM_SEED)
    permutation = rng.permutation(len(X))
    train_idx = permutation[:1800]
    validation_idx = permutation[1800:2400]
    test_idx = permutation[2400:]
    X_train, y_train = X.iloc[train_idx], y.iloc[train_idx]
    X_validation, y_validation = X.iloc[validation_idx], y.iloc[validation_idx]
    X_test, y_test = X.iloc[test_idx], y.iloc[test_idx]

    candidates = {
        "OLS": LinearRegression(),
        **{f"Ridge ({alpha:.2f})": Ridge(alpha=alpha) for alpha in [0.10, 0.30, 0.60]},
        **{f"Lasso ({alpha:.2f})": Lasso(alpha=alpha, max_iter=50_000)
           for alpha in [0.02, 0.06, 0.10]},
    }
    models = {}
    rows = []
    for name, estimator in candidates.items():
        model = make_model(estimator)
        model.fit(X_train, y_train)
        models[name] = model
        train_metrics = log_metrics(y_train, model.predict(X_train))
        validation_metrics = log_metrics(y_validation, model.predict(X_validation))
        rows.append({
            "model": name,
            **{f"train_{key}": value for key, value in train_metrics.items()},
            **{f"validation_{key}": value for key, value in validation_metrics.items()},
        })
    results = pd.DataFrame(rows).sort_values("validation_mse").reset_index(drop=True)
    best_name = results.loc[0, "model"]

    development_X = pd.concat([X_train, X_validation])
    development_y = pd.concat([y_train, y_validation])
    final_model = make_model(candidates[best_name])
    final_model.fit(development_X, development_y)
    test_prediction = final_model.predict(X_test)

    # Validation-MSE comparison.
    sns.set_theme(style="whitegrid", context="notebook")
    plot_results = results.sort_values("validation_mse", ascending=True)
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    colors = ["#0B6E75" if name == best_name else "#8DB9BD" for name in plot_results["model"]]
    ax.barh(plot_results["model"], plot_results["validation_mse"], color=colors)
    ax.invert_yaxis()
    ax.set_xlabel("Validation MSE on log1p(SalePrice)")
    ax.set_ylabel("")
    ax.set_title("Validation performance of the seven candidate models")
    ax.set_xlim(0, plot_results["validation_mse"].max() * 1.16)
    for position, value in enumerate(plot_results["validation_mse"]):
        ax.text(value + 0.00025, position, f"{value:.5f}", va="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(FIGURE_DIR / "validation_mse.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    # Held-out predictions.
    fig, ax = plt.subplots(figsize=(6.4, 5.6))
    ax.scatter(y_test, test_prediction, s=24, alpha=0.58, color="#0B6E75", edgecolor="none")
    limits = [min(y_test.min(), test_prediction.min()), max(y_test.max(), test_prediction.max())]
    ax.plot(limits, limits, "--", color="#A63D40", linewidth=1.5, label="Perfect prediction")
    ax.set_xlim(limits)
    ax.set_ylim(limits)
    ax.set_xlabel("Actual SalePrice (USD)")
    ax.set_ylabel("Predicted SalePrice (USD)")
    ax.set_title(f"Held-out test predictions: {best_name}")
    ax.legend(frameon=True)
    fig.tight_layout()
    fig.savefig(FIGURE_DIR / "test_predictions.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    # Log residual diagnostics.
    predicted_log = np.log1p(np.maximum(test_prediction, 0))
    residuals = np.log1p(y_test.to_numpy()) - predicted_log
    fig, axes = plt.subplots(1, 2, figsize=(9.4, 4.0))
    axes[0].scatter(predicted_log, residuals, s=22, alpha=0.55, color="#0B6E75", edgecolor="none")
    axes[0].axhline(0, color="#A63D40", linestyle="--", linewidth=1.3)
    axes[0].set_xlabel("Predicted log1p(SalePrice)")
    axes[0].set_ylabel("Log residual")
    axes[0].set_title("Residuals versus fitted values")
    sns.histplot(residuals, bins=28, kde=True, color="#0B6E75", ax=axes[1])
    axes[1].set_xlabel("Log residual")
    axes[1].set_ylabel("Count")
    axes[1].set_title("Test residual distribution")
    fig.tight_layout()
    fig.savefig(FIGURE_DIR / "test_residuals.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    # Recover one numerical parameter vector for the selected OLS fit. Because the
    # 47-feature design is rank deficient, this vector is not unique and is listed
    # only for reproducibility. The report uses Ridge (alpha=0.60) for a stable
    # coefficient-pattern sensitivity plot.
    regressor = final_model.regressor_
    preprocess = regressor.named_steps["preprocess"]
    estimator = regressor.named_steps["model"]
    names = list(preprocess.get_feature_names_out())
    target_scaler = final_model.transformer_.named_steps["scale"]
    predictor_scaler = preprocess.named_transformers_["scaled"]
    means = pd.Series(0.0, index=names)
    scales = pd.Series(1.0, index=names)
    means.loc[scaled_features] = predictor_scaler.mean_
    scales.loc[scaled_features] = predictor_scaler.scale_
    original_slopes = pd.Series(estimator.coef_ * target_scaler.scale_[0], index=names) / scales
    original_intercept = float(
        target_scaler.mean_[0]
        + target_scaler.scale_[0] * estimator.intercept_
        - original_slopes.dot(means)
    )
    parameter_table = pd.concat([pd.Series({"Intercept": original_intercept}), original_slopes])

    ridge_interpretation_model = make_model(Ridge(alpha=0.60))
    ridge_interpretation_model.fit(development_X, development_y)
    ridge_regressor = ridge_interpretation_model.regressor_
    ridge_estimator = ridge_regressor.named_steps["model"]
    ridge_names = ridge_regressor.named_steps["preprocess"].get_feature_names_out()
    ridge_target_scale = ridge_interpretation_model.transformer_.named_steps["scale"].scale_[0]
    standardized_effects = pd.Series(
        ridge_estimator.coef_ * ridge_target_scale, index=ridge_names
    )
    top_effects = standardized_effects.abs().sort_values(ascending=False).head(15).index
    top_table = standardized_effects.loc[top_effects].sort_values()
    fig, ax = plt.subplots(figsize=(7.4, 5.6))
    effect_colors = ["#A63D40" if value < 0 else "#0B6E75" for value in top_table]
    ax.barh([name.replace("NBHD_", "") for name in top_table.index], top_table.values,
            color=effect_colors)
    ax.axvline(0, color="#555555", linewidth=0.8)
    ax.set_xlabel("Coefficient on standardized predictor (log-price units)")
    ax.set_ylabel("")
    ax.set_title("Largest stable coefficients: Ridge alpha = 0.60")
    fig.tight_layout()
    fig.savefig(FIGURE_DIR / "top_coefficients.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    # Generate a longtable fragment with every final OLS parameter.
    lines = [
        r"\begin{longtable}{@{}lr@{}}",
        r"\caption{One numerical parameter vector for the final OLS fit.}\label{tab:final-parameters}\\",
        r"\toprule",
        r"Parameter & Coefficient \\",
        r"\midrule",
        r"\endfirsthead",
        r"\toprule",
        r"Parameter & Coefficient \\",
        r"\midrule",
        r"\endhead",
        r"\midrule",
        r"\multicolumn{2}{r}{Continued on next page} \\",
        r"\endfoot",
        r"\bottomrule",
        r"\endlastfoot",
    ]
    for name, value in parameter_table.items():
        lines.append(f"{latex_escape(name)} & {value:.17g} \\\\")
    lines.append(r"\end{longtable}")
    (OUTPUT_DIR / "final_ols_parameters.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")

    test_values = log_metrics(y_test, test_prediction)
    dollar_rmse = np.sqrt(mean_squared_error(y_test, test_prediction))
    dollar_mae = mean_absolute_error(y_test, test_prediction)
    summary = pd.Series({
        "selected_model": best_name,
        **test_values,
        "dollar_rmse": dollar_rmse,
        "dollar_mae": dollar_mae,
    })
    summary.to_csv(OUTPUT_DIR / "model_summary.csv", header=["value"])
    results.to_csv(OUTPUT_DIR / "candidate_metrics.csv", index=False)
    print(results.to_string(index=False))
    print("\nFinal test summary:\n", summary.to_string())


if __name__ == "__main__":
    main()
